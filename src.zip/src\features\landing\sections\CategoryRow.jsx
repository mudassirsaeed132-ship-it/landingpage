import Container from "../../../shared/ui/Container";
import Card from "../../../shared/ui/Card";
import { CATEGORY_TILES } from "../../../config/siteContent";
import { Link } from "react-router-dom";

export default function CategoryRow() {
  return (
    <Container className="py-8">
      <Card className="px-4 py-5">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {CATEGORY_TILES.map((c) => (
            <Link
              key={c.to}
              to={c.to}
              className="flex items-center gap-3 rounded-xl border border-black/10 bg-white px-4 py-3 hover:bg-black/[0.02]"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#D86C5E]/10 text-[#D86C5E]">
                🧭
              </div>
              <div className="text-sm font-medium text-gray-800">{c.label}</div>
            </Link>
          ))}
        </div>
      </Card>
    </Container>
  );
}