import Card from "../../../../shared/ui/Card";
import Button from "../../../../shared/ui/Button";

export default function ListingCard({ item }) {
  return (
    <Card className="overflow-hidden">
      <div className="relative aspect-[16/10]">
        <img
          src={item.image}
          alt={item.title}
          className="h-full w-full object-cover"
          loading="lazy"
        />

        <div className="absolute left-3 top-3 flex gap-2">
          {item.verified && (
            <span className="rounded-full bg-white px-2 py-1 text-[10px] font-medium text-gray-800 shadow">
              Owner Verified
            </span>
          )}
          {item.isNew && (
            <span className="rounded-full bg-white px-2 py-1 text-[10px] font-medium text-gray-800 shadow">
              New
            </span>
          )}
        </div>

        <button className="absolute right-3 top-3 h-8 w-8 rounded-full bg-white/95 text-sm shadow hover:bg-white">
          ♡
        </button>

        <button className="absolute left-2 top-1/2 -translate-y-1/2 h-7 w-7 rounded-full bg-white/90 shadow">
          ‹
        </button>
        <button className="absolute right-2 top-1/2 -translate-y-1/2 h-7 w-7 rounded-full bg-white/90 shadow">
          ›
        </button>
      </div>

      <div className="p-4">
        <div className="text-sm font-semibold text-gray-900">{item.title}</div>
        <div className="mt-1 text-xs text-gray-500">📍 {item.address}</div>

        <div className="mt-3 flex items-center justify-between">
          <div className="text-sm font-semibold text-gray-900">{item.price}</div>
        </div>

        <div className="mt-3 flex items-center gap-3 text-xs text-gray-600">
          <span>🛏 {item.beds}rms</span>
          <span>🛁 {item.baths} </span>
          <span>📐 {item.area}</span>
        </div>

        <div className="mt-4 grid grid-cols-3 gap-2">
          <Button variant="ghost" className="h-9 rounded-xl text-xs">
            Chat
          </Button>
          <Button variant="ghost" className="h-9 rounded-xl text-xs">
            Book Visit
          </Button>
          <Button variant="ghost" className="h-9 rounded-xl text-xs">
            Pre check
          </Button>
        </div>
      </div>
    </Card>
  );
}