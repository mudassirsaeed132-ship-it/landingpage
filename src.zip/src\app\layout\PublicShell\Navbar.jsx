import { Link } from "react-router-dom";
import Container from "../../../shared/ui/Container";
import Button from "../../../shared/ui/Button";
import { NAV_LINKS, BRAND } from "../../../config/siteContent";

export default function Navbar() {
  return (
    <header className="w-full">
      {/* top coral strip */}
      <div className="h-3 w-full bg-[#D86C5E]" />

      {/* main nav */}
      <div className="border-b border-black/10 bg-white">
        <Container className="flex items-center justify-between py-3">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-black/10">
              🏠
            </div>
            <div className="leading-tight">
              <div className="text-[11px] font-semibold tracking-wide text-[#D86C5E] whitespace-pre">
                {BRAND.logoMark}
              </div>
            </div>
          </Link>

          {/* desktop nav */}
          <nav className="hidden lg:flex items-center gap-6 text-sm">
            {NAV_LINKS.map((l) => (
              <Link key={l.to} to={l.to} className="text-gray-700 hover:text-[#D86C5E]">
                {l.label}
              </Link>
            ))}
          </nav>

          {/* right actions */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 text-xs text-gray-500">
              <span className="h-2 w-2 rounded-full bg-[#D86C5E]" />
              <span>EN</span>
            </div>
            <Link to="/auth" className="text-sm text-[#D86C5E] hover:underline">
              Login <span className="text-gray-400">/</span> SignUp
            </Link>
            <Button className="hidden md:inline-flex" size="sm">
              List Property
            </Button>
          </div>
        </Container>
      </div>
    </header>
  );
}