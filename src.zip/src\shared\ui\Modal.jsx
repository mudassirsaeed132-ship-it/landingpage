import { useEffect, useRef } from "react";
import useLockBodyScroll from "../hooks/useLockBodyScroll";
import useOutsideClick from "../hooks/useOutsideClick";
import { cn } from "../lib/cn";

export default function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  maxWidth = "max-w-3xl",
}) {
  const panelRef = useRef(null);
  useLockBodyScroll(open);
  useOutsideClick(panelRef, onClose, open);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === "Escape" && onClose?.();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-black/40" />
      <div
        ref={panelRef}
        className={cn(
          "relative w-full rounded-2xl bg-white shadow-xl",
          maxWidth
        )}
      >
        {(title || onClose) && (
          <div className="flex items-center justify-between border-b border-black/10 px-5 py-4">
            <div className="text-sm font-semibold text-gray-900">{title}</div>
            <button
              onClick={onClose}
              className="rounded-lg px-2 py-1 text-gray-600 hover:bg-black/[0.04]"
            >
              ✕
            </button>
          </div>
        )}

        <div className="max-h-[75vh] overflow-auto px-5 py-5">{children}</div>

        {footer && (
          <div className="border-t border-black/10 px-5 py-4">{footer}</div>
        )}
      </div>
    </div>
  );
}