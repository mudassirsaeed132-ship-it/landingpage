import Container from "../../../shared/ui/Container";
import Input from "../../../shared/ui/Input";
import Button from "../../../shared/ui/Button";
import { HERO } from "../../../config/siteContent";

export default function HeroSection() {
  return (
    <section
      className="relative h-[420px] w-full overflow-hidden"
      style={{
        backgroundImage:
          "url(https://images.unsplash.com/photo-1501183638710-841dd1904471?auto=format&fit=crop&w=1800&q=60)",
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="absolute inset-0 bg-black/45" />

      <Container className="relative flex h-full items-center">
        <div className="w-full">
          <h1 className="text-center text-3xl font-semibold text-white md:text-5xl">
            {HERO.title}
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-center text-sm text-white/80 md:text-base">
            {HERO.subtitle}
          </p>

          {/* Search bar */}
          <div className="mx-auto mt-8 flex w-full max-w-3xl flex-col gap-3 rounded-2xl bg-white/95 p-3 shadow-lg sm:flex-row sm:items-center">
            <div className="flex-1">
              <Input placeholder={HERO.search.locationPlaceholder} />
            </div>
            <div className="flex-1">
              <Input placeholder={HERO.search.pricePlaceholder} />
            </div>
            <Button className="w-full sm:w-auto">{HERO.search.cta}</Button>
          </div>

          {/* quick facts */}
          <div className="mt-4 flex flex-wrap justify-center gap-4 text-xs text-white/80">
            {HERO.quickFacts.map((t) => (
              <span key={t} className="rounded-full bg-white/10 px-3 py-1">
                {t}
              </span>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}