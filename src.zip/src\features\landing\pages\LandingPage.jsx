import HeroSection from "../sections/HeroSection";
import CategoryRow from "../sections/CategoryRow";
import ListingRow from "../sections/ListingRow";
import PrecheckBanner from "../sections/PrecheckBanner";
import AppDownloadStrip from "../sections/AppDownloadStrip";
import { HOME_SECTIONS } from "../../../config/siteContent";
import { MOCK_LISTINGS } from "../data/landing.mock";

export default function LandingPage() {
  return (
    <div>
      <HeroSection />
      <CategoryRow />

      <div className="space-y-10 py-10">
        {HOME_SECTIONS.map((s) => (
          <ListingRow
            key={s.key}
            title={s.title}
            subtitle={s.subtitle}
            viewAllTo={s.viewAllTo}
            items={MOCK_LISTINGS}
          />
        ))}
      </div>

      <PrecheckBanner />
      <AppDownloadStrip />
    </div>
  );
}