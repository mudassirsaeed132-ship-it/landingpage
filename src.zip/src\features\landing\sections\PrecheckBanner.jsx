import Container from "../../../shared/ui/Container";
import Button from "../../../shared/ui/Button";
import { PRECHECK_BANNER } from "../../../config/siteContent";

export default function PrecheckBanner() {
  return (
    <section className="mt-10 bg-[#D86C5E] py-10">
      <Container className="flex flex-col items-start justify-between gap-6 lg:flex-row lg:items-center">
        <div className="text-white">
          <h3 className="text-xl font-semibold">{PRECHECK_BANNER.title}</h3>
          <p className="mt-2 max-w-2xl text-sm text-white/85">
            {PRECHECK_BANNER.subtitle}
          </p>
        </div>
        <Button variant="outline" className="border-white text-white hover:bg-white/10">
          {PRECHECK_BANNER.cta}
        </Button>
      </Container>
    </section>
  );
}