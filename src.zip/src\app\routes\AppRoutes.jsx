import { Suspense } from "react";
import { useRoutes } from "react-router-dom";
import { routes } from "./routeConfig";

function PageLoader() {
  return (
    <div className="flex min-h-[50vh] items-center justify-center text-sm text-gray-500">
      Loading...
    </div>
  );
}

export default function AppRoutes() {
  const element = useRoutes(routes);
  return <Suspense fallback={<PageLoader />}>{element}</Suspense>;
}