export const MOCK_LISTINGS = Array.from({ length: 8 }).map((_, i) => ({
  id: `L-${i + 1}`,
  title: "Modern Luxury Apartment",
  address: "Bahnhofstrasse 12, Zurich",
  price: i % 2 === 0 ? "$1,250,000" : "$4,500 / month",
  beds: 4,
  baths: 5,
  area: "120m²",
  verified: true,
  isNew: i % 3 === 0,
  image:
    "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1200&q=60",
}));