import Container from "../../../shared/ui/Container";
import { APP_STRIP } from "../../../config/siteContent";

export default function AppDownloadStrip() {
  return (
    <section className="bg-[#F4DCD8] py-10">
      <Container className="grid grid-cols-1 items-center gap-6 md:grid-cols-3">
        <div className="md:col-span-1">
          <h3 className="text-xl font-semibold text-[#D86C5E]">{APP_STRIP.title}</h3>
          <p className="mt-1 text-sm text-gray-600">{APP_STRIP.subtitle}</p>
        </div>

        <div className="md:col-span-1 flex items-center justify-center">
          <div className="h-20 w-40 rounded-xl bg-white/70" />
        </div>

        <div className="md:col-span-1 flex items-center justify-start gap-3 md:justify-end">
          <div className="h-10 w-28 rounded-lg bg-black/90" />
          <div className="h-10 w-28 rounded-lg bg-black/90" />
        </div>
      </Container>
    </section>
  );
}