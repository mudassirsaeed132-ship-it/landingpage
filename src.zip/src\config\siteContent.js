// src/config/siteContent.js

export const THEME = {
  brand: "#D86C5E",          // coral from your UI
  softBg: "#F4DCD8",         // footer light pink
  text: "#111827",
  muted: "#6B7280",
};

export const BRAND = {
  name: "REAL ESTATE",
  logoMark: "REAL\nESTATE",
};

export const NAV_LINKS = [
  { label: "Houses", to: "/search?type=houses" },
  { label: "Apartments", to: "/search?type=apartments" },
  { label: "Land", to: "/search?type=land" },
  { label: "Commercial", to: "/search?type=commercial" },
  { label: "Buy", to: "/search?intent=buy" },
  { label: "Rent", to: "/search?intent=rent" },
  { label: "Short - Stay", to: "/search?intent=shortstay" },
];

export const HERO = {
  title: "Buy, Sell & Rent",
  subtitle:
    "The modern platform for verified private owners and seekers. Skip the middleman, save fees, and deal directly.",
  search: {
    locationPlaceholder: "Where do you want to live?",
    pricePlaceholder: "Price range",
    cta: "Search",
  },
  quickFacts: ["No Agent Fees", "Verified Owners", "New Listings", "Price Drop"],
};

export const CATEGORY_TILES = [
  { label: "Buy", to: "/search?intent=buy" },
  { label: "Rent", to: "/search?intent=rent" },
  { label: "Land", to: "/search?type=land" },
  { label: "Commercial", to: "/search?type=commercial" },
  { label: "Short-stay", to: "/search?intent=shortstay" },
];

export const HOME_SECTIONS = [
  {
    key: "new-this-week",
    title: "New this week",
    subtitle: "Fresh properties just added by owners",
    viewAllTo: "/search?sort=new",
  },
  {
    key: "short-stays",
    title: "Short Stays & Rentals",
    subtitle: "Flexible bookings directly from hosts",
    viewAllTo: "/search?intent=shortstay",
  },
  {
    key: "buy-new-house",
    title: "Buy your New House Today",
    subtitle: "Find verified listings in your budget",
    viewAllTo: "/search?intent=buy",
  },
  {
    key: "top-deals-land",
    title: "Top deals on lands",
    subtitle: "Verified owners, direct connections",
    viewAllTo: "/search?type=land",
  },
  {
    key: "commercial-sites",
    title: "Commercial Sites for your Corporate & Commercial Needs",
    subtitle: "Verified owners, direct connections",
    viewAllTo: "/search?type=commercial",
  },
];

export const PRECHECK_BANNER = {
  title: "Get your budget in 3 minutes",
  subtitle:
    "Get a financing pre-check certificate from our partner banks. Increases your chances of getting the property by 3x.",
  cta: "Start Pre-check",
  to: "/precheck",
};

export const APP_STRIP = {
  title: "Find amazing deals on the go.",
  subtitle: "Download Real estate app now!",
};

export const FOOTER = {
  columns: [
    {
      title: "Popular Categories",
      links: [
        { label: "Rent", to: "/search?intent=rent" },
        { label: "Buy", to: "/search?intent=buy" },
        { label: "Land", to: "/search?type=land" },
        { label: "Commercial", to: "/search?type=commercial" },
      ],
    },
    {
      title: "Trending Searches",
      links: [
        { label: "Land", to: "/search?type=land" },
        { label: "Short-stay", to: "/search?intent=shortstay" },
        { label: "Shop", to: "/search?type=shop" },
        { label: "Flats", to: "/search?type=flats" },
      ],
    },
    {
      title: "About Us",
      links: [
        { label: "RS Blog", to: "/blog" },
        { label: "Contact Us", to: "/contact" },
        { label: "RS for Businesses", to: "/business" },
      ],
    },
    {
      title: "OLX",
      links: [
        { label: "Help", to: "/help" },
        { label: "Sitemap", to: "/sitemap" },
        { label: "Terms of use", to: "/terms" },
        { label: "Privacy Policy", to: "/privacy" },
      ],
    },
  ],
  socials: ["x", "facebook", "youtube", "instagram"],
  copyright: "© Real state Copyrights",
};