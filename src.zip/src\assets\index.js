// Brand images
import logo from "./brand/logo.png";
import logoFull from "./brand/logo-full.png";

// Category icons
import buy from "./categories/buy.png";
import commercial from "./categories/commercial.png";
import land from "./categories/land.png";
import rent from "./categories/rent.png";
import shortStay from "./categories/short-stay.png";

// Hero image
import heroImg from "./hero/hero.jpg";

// Listing images
import listing1 from "./listings/listing-1.png";
import listing2 from "./listings/listing-2.png";
import listing3 from "./listings/listing-3.png";
import listing4 from "./listings/listing-4.png";

// UI images (for app store logos, etc.)
import appMock from "./ui/app-mock.png";
import appGallery from "./ui/app-gallery.png";
import googlePlay from "./ui/google-play.png";

// Exporting images for reuse
export const Images = {
  brand: {
    logo,
    logoFull,
  },

  categories: {
    buy,
    commercial,
    land,
    rent,
    shortStay,
  },

  heroImg,

  listings: {
    listing1,
    listing2,
    listing3,
    listing4,
  },

  ui: {
    appMock,
    appGallery,
    googlePlay,
  },
};