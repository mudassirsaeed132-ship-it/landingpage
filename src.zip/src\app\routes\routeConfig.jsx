import { lazyImport } from "./Lazy";
import PublicShell from "../layout/PublicShell/PublicShell";

const LandingPage = lazyImport(() => import("../../features/landing/pages/LandingPage"));
const SearchPage = lazyImport(() => import("../../features/search/pages/SearchPage"));
const ListingDetailPage = lazyImport(() => import("../../features/listing/pages/ListingDetailPage"));

export const routes = [
  {
    element: <PublicShell />,
    children: [
      { path: "/", element: <LandingPage /> },
      { path: "/search", element: <SearchPage /> },
      { path: "/listing/:id", element: <ListingDetailPage /> },
    ],
  },
];