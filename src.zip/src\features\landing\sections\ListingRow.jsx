import Container from "../../../shared/ui/Container";
import { Link } from "react-router-dom";
import ListingCard from "../sections/components/ListingCard";

export default function ListingRow({ title, subtitle, viewAllTo, items }) {
  return (
    <Container>
      <div className="mb-4 flex items-end justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-[#D86C5E]">{title}</h2>
          <p className="text-sm text-gray-500">{subtitle}</p>
        </div>
        <Link to={viewAllTo} className="text-sm text-[#D86C5E] hover:underline">
          View all
        </Link>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {items.slice(0, 4).map((it) => (
          <ListingCard key={it.id} item={it} />
        ))}
      </div>
    </Container>
  );
}