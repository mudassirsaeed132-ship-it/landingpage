import { Link } from "react-router-dom";
import Container from "../../../shared/ui/Container";
import { FOOTER } from "../../../config/siteContent";

export default function Footer() {
  return (
    <footer className="mt-10 bg-[#F4DCD8]">
      <Container className="py-10">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-5">
          {FOOTER.columns.map((col) => (
            <div key={col.title}>
              <div className="text-sm font-semibold text-[#D86C5E]">{col.title}</div>
              <div className="mt-3 space-y-2">
                {col.links.map((l) => (
                  <Link
                    key={l.to}
                    to={l.to}
                    className="block text-sm text-gray-700 hover:text-[#D86C5E]"
                  >
                    {l.label}
                  </Link>
                ))}
              </div>
            </div>
          ))}

          <div>
            <div className="text-sm font-semibold text-[#D86C5E]">Follow Us</div>
            <div className="mt-3 flex items-center gap-3">
              {FOOTER.socials.map((s) => (
                <button
                  key={s}
                  className="h-9 w-9 rounded-full border border-black/10 bg-white text-xs text-gray-600 hover:bg-black/[0.03]"
                  aria-label={s}
                >
                  {s[0].toUpperCase()}
                </button>
              ))}
            </div>
          </div>
        </div>
      </Container>

      <div className="bg-[#D86C5E] py-3">
        <Container className="text-center text-sm text-white">
          {FOOTER.copyright}
        </Container>
      </div>
    </footer>
  );
}