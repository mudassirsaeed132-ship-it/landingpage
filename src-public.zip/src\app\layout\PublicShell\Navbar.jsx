import { useMemo, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { IMG } from "../../../config/images";
import { NAV_LINKS } from "../../../config/siteContent";
import Container from "../../../shared/ui/Container";
import IconButton from "../../../shared/ui/IconButton";
import MobileNavDrawer from "./MobileNavDrawer";
import { useUI } from "../../../shared/ui/UIProvider";

// src/app/layout/PublicShell/Navbar.jsx  (TopBar only)

function TopBar() {
  return (
    <div className="bg-[#D66557] text-white">
      <Container className="flex h-10 items-center justify-end gap-6 text-[12px]">
        {/* Phone */}
        <span className="flex items-center gap-2">
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" aria-hidden="true">
            <path
              d="M7 3h3l2 5-2 1c1 3 3 5 6 6l1-2 5 2v3c0 1-1 2-2 2-9 0-16-7-16-16 0-1 1-2 2-2Z"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinejoin="round"
            />
          </svg>
          <span className="font-medium">+31 (0) 12 345 6789</span>
        </span>

        {/* Flag only (no EN text) */}
        <span className="flex items-center">
          <img
            src={IMG.brand.flagUK}
            alt="UK"
            className="h-4 w-6 rounded-[3px] object-cover"
            draggable={false}
          />
        </span>

        {/* Globe pill EN (wider like figma) */}
        <span className="flex items-center gap-2 rounded-full border border-white/70 px-5 py-[6px] leading-none">
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" aria-hidden="true">
            <path
              d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z"
              stroke="currentColor"
              strokeWidth="2"
            />
            <path d="M3 12h18" stroke="currentColor" strokeWidth="2" />
            <path
              d="M12 3c2.5 2.8 2.5 15.2 0 18-2.5-2.8-2.5-15.2 0-18Z"
              stroke="currentColor"
              strokeWidth="2"
            />
          </svg>
          <span className="font-medium">EN</span>
        </span>
      </Container>
    </div>
  );
}

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const { openAuth } = useUI();

  const links = useMemo(() => NAV_LINKS, []);

  return (
    <header className="sticky top-0 z-50 bg-white">
      <TopBar />

      <div className="border-b border-black/5">
        <Container className="flex h-16 items-center justify-between gap-4">
          {/* Left: Logo */}
          <Link to="/" className="flex items-center gap-3">
            <img
              src={IMG.brand.logoFull}
              alt="Real Estate"
              className="h-9 w-auto"
              draggable={false}
            />
          </Link>

          {/* Center: links (desktop) */}
          <nav className="hidden items-center gap-8 md:flex">
            {links.map((l) => (
              <NavLink
                key={l.label}
                to={l.to}
                className={({ isActive }) =>
                  `text-sm font-medium ${
                    isActive
                      ? "text-[#D66557]"
                      : "text-slate-700 hover:text-slate-900"
                  }`
                }
              >
                {l.label}
              </NavLink>
            ))}
          </nav>

          {/* Right */}
          <div className="flex items-center gap-2">
            <button
              onClick={openAuth}
              className="hidden text-sm font-semibold text-[#D66557] md:inline"
            >
              Login <span className="text-slate-400">/</span> Signup
            </button>

            <IconButton
              onClick={() => setOpen(true)}
              className="md:hidden"
              ariaLabel="Open menu"
            >
              ☰
            </IconButton>
          </div>
        </Container>
      </div>

      <MobileNavDrawer open={open} onClose={() => setOpen(false)} />
    </header>
  );
}