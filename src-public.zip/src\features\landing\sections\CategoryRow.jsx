import { IMG } from "../../../config/images";
import Container from "../../../shared/ui/Container";

const CATS = [
  { key: "buy", label: "Buy", icon: IMG.categories.buy },
  { key: "rent", label: "Rent", icon: IMG.categories.rent },
  { key: "land", label: "Land", icon: IMG.categories.land },
  { key: "commercial", label: "Commercial", icon: IMG.categories.commercial },
  { key: "shortStay", label: "Short-Stay", icon: IMG.categories.shortStay },
];

export default function CategoryRow() {
  return (
    <Container>
      <div className="grid grid-cols-2 gap-10 sm:grid-cols-3 md:grid-cols-5">
        {CATS.map((c) => (
          <div key={c.key} className="flex flex-col items-center">
            <div className="grid h-16 w-16 place-items-center rounded-2xl bg-slate-50">
              <img src={c.icon} alt={c.label} className="h-9 w-9" loading="lazy" />
            </div>
            <p className="mt-3 text-sm font-medium text-slate-800">{c.label}</p>
          </div>
        ))}
      </div>

      {/* ✅ Divider line under category icons (like screenshot) */}
      <div className="mt-10 h-px w-full bg-slate-200/80" />
    </Container>
  );
}