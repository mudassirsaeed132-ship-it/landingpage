import Modal from "../../../shared/ui/Modal";
import { useUI } from "../../../shared/ui/UIProvider";
import { IMG } from "../../../config/images";

export default function AuthModal() {
  const { authOpen, closeAuth } = useUI();

  return (
    <Modal open={authOpen} onClose={closeAuth}>
      <div className="w-full max-w-2xl rounded-2xl bg-white p-10 shadow-xl">
        <div className="flex flex-col items-center text-center">
          <img src={IMG.brand.logoFull} alt="Real Estate" className="h-10 w-auto" />
          <h2 className="mt-6 text-3xl font-extrabold">Login or Signup</h2>
          <p className="mt-2 text-sm text-slate-500">
            You can access and discover more app patterns by logging in or signing up
          </p>

          <button className="mt-8 w-full rounded-xl bg-[#D66557] py-4 text-sm font-semibold text-white">
            Login
          </button>

          <p className="mt-3 text-sm text-slate-500">
            Don’t have an account?{" "}
            <button className="font-semibold text-[#D66557]">Sign up</button>
          </p>
        </div>
      </div>
    </Modal>
  );
}