import Container from "../../../shared/ui/Container";
import { FOOTER_LINKS } from "../../../config/siteContent";
import { IMG } from "../../../config/images";

export default function Footer() {
  return (
    <footer>
      {/* Download strip + footer links (same pink background) */}
      <section className="bg-[#F7E3E0] py-12">
        <Container>
          {/* download strip */}
          <div className="grid grid-cols-1 items-center gap-10 md:grid-cols-3">
            <div>
              <p className="text-lg font-semibold text-[#D66557]">
                Find amazing deals on the go.
              </p>
              <h3 className="mt-2 text-2xl font-extrabold text-slate-900">
                Download Real estate app now!
              </h3>
            </div>

            <div className="flex justify-center">
              <img
                src={IMG.ui.appMock}
                alt="App mock"
                className="h-44 w-auto md:h-52"
                loading="lazy"
              />
            </div>

            <div className="flex flex-wrap items-center justify-center gap-4 md:justify-end">
              <img
                src={IMG.ui.googlePlay}
                alt="Google Play"
                className="h-12 w-auto"
                loading="lazy"
              />
              <img
                src={IMG.ui.appGallery}
                alt="AppGallery"
                className="h-12 w-auto"
                loading="lazy"
              />
            </div>
          </div>

          {/* links */}
          <div className="mt-14 grid grid-cols-2 gap-10 md:grid-cols-5">
            {FOOTER_LINKS.map((col) => (
              <div key={col.title}>
                <h4 className="text-sm font-semibold text-[#D66557]">{col.title}</h4>
                <ul className="mt-4 space-y-3 text-sm text-[#D66557]">
                  {col.links.map((t) => (
                    <li key={t} className="cursor-pointer hover:opacity-80">
                      {t}
                    </li>
                  ))}
                </ul>
              </div>
            ))}

            {/* socials */}
            <div className="col-span-2 md:col-span-1 md:justify-self-end">
              <h4 className="text-sm font-semibold text-[#D66557]">Follow Us</h4>
              <div className="mt-4 flex items-center gap-4">
                {["X", "f", "▶", "◎"].map((t) => (
                  <button
                    key={t}
                    className="grid h-12 w-12 place-items-center rounded-full border border-black/40 text-slate-900"
                    aria-label="Social"
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </Container>
      </section>

      {/* bottom bar */}
      <div className="bg-[#D66557] py-6 text-white">
        <Container className="flex justify-end text-sm">
          © Real state Copyrights
        </Container>
      </div>
    </footer>
  );
}