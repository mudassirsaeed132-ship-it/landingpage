import { useParams } from "react-router-dom";
import Container from "../../../shared/ui/Container";

export default function ListingDetailPage() {
  const { id } = useParams();
  return (
    <main className="py-10">
      <Container>
        <h1 className="text-2xl font-extrabold">Listing Detail</h1>
        <p className="mt-2 text-sm text-slate-600">Listing ID: {id}</p>
      </Container>
    </main>
  );
}