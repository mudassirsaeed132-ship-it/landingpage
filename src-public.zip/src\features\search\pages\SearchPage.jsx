import Container from "../../../shared/ui/Container";

export default function SearchPage() {
  return (
    <main className="py-10">
      <Container>
        <h1 className="text-2xl font-extrabold">Search</h1>
        <p className="mt-2 text-sm text-slate-600">
          (Placeholder) Yahan aap grid + map view implement kar sakte ho.
        </p>
      </Container>
    </main>
  );
}