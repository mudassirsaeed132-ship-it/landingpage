// src/config/siteContent.js

export const SITE = {
  hero: {
    title: "Buy, Sell & Rent",
    subtitle:
      "The modern platform for verified private owners and seekers. Skip the middleman, save fees, and deal directly.",
    placeholders: {
      location: "Where do you want to live?",
      price: "Price range",
    },
    cta: {
      search: "Search",
    },
    trust: ["No Agent Fees", "Verified Owners", "New Listings", "Price Drop"],
  },

  listing: {
    viewAll: "View all",
    details: "Details",
    badges: {
      verified: "Owner Verified",
      new: "New",
    },
  },

  footer: {
    followTitle: "Follow Us",
    copyright: "© Real state Copyrights",
  },
};

// ✅ Navbar menu (restore)
export const NAV_LINKS = [
  { label: "Houses", to: "/search" },
  { label: "Apartments", to: "/search" },
  { label: "Land", to: "/search" },
  { label: "Commercial", to: "/search" },
  { label: "Buy", to: "/search" },
  { label: "Rent", to: "/search" },
  { label: "Short- Stay", to: "/search" },
];

// ✅ Footer columns (Cities removed)
export const FOOTER_LINKS = [
  { title: "Popular Categories", links: ["Rent", "Buy", "Land", "Commercial"] },
  { title: "Trending Searches", links: ["Land", "Short-stay", "Shop", "flats"] },
  { title: "About Us", links: ["RS Blog", "Contact Us", "RS for Businesses"] },
  { title: "OLX", links: ["Help", "Sitemap", "Terms of use", "Privacy Policy"] },
];

// ✅ Follow Us links (config-driven)
export const SOCIAL_LINKS = [
  { key: "x", label: "X", href: "#" },
  { key: "facebook", label: "Facebook", href: "#" },
  { key: "youtube", label: "YouTube", href: "#" },
  { key: "instagram", label: "Instagram", href: "#" },
];