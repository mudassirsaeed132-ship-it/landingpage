import { cn } from "../lib/cn";

export default function IconButton({ children, className, ariaLabel, ...props }) {
  return (
    <button
      aria-label={ariaLabel}
      className={cn(
        "grid h-10 w-10 place-items-center rounded-xl border border-black/10 bg-white text-slate-900 hover:bg-slate-50",
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}