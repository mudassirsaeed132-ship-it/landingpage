import React from "react";
import { SITE } from "../../../../config/siteContent";

function cn(...c) {
  return c.filter(Boolean).join(" ");
}

function IconHeart({ className }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" aria-hidden="true">
      <path
        d="M12.1 20.2s-7.1-4.3-9.3-8.1C.7 8.5 2.5 5.5 5.8 5.2c1.8-.2 3.5.7 4.4 2 1-1.3 2.6-2.2 4.4-2 3.3.3 5.1 3.3 3 6.9-2.2 3.8-9.3 8.1-9.3 8.1Z"
        stroke="#D66557"
        strokeWidth="2"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function IconPin({ className }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" aria-hidden="true">
      <path
        d="M12 21s7-6.2 7-12A7 7 0 0 0 5 9c0 5.8 7 12 7 12Z"
        stroke="#111827"
        strokeWidth="2"
      />
      <circle cx="12" cy="9" r="2.2" stroke="#111827" strokeWidth="2" />
    </svg>
  );
}

function IconBed({ className }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" aria-hidden="true">
      <path d="M3 12h18" stroke="#111827" strokeWidth="2" strokeLinecap="round" />
      <path
        d="M4 12V8.8c0-1 0.8-1.8 1.8-1.8h5.4c1 0 1.8.8 1.8 1.8V12"
        stroke="#111827"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <path d="M3 12v7M21 12v7" stroke="#111827" strokeWidth="2" strokeLinecap="round" />
      <path d="M3 16h18" stroke="#111827" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function IconArea({ className }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" aria-hidden="true">
      <path
        d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M8 21H5a2 2 0 0 1-2-2v-3M16 21h3a2 2 0 0 0 2-2v-3"
        stroke="#111827"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
}

function Price({ value }) {
  const slashIdx = value?.indexOf("/") ?? -1;
  if (slashIdx > -1) {
    const left = value.slice(0, slashIdx);
    const right = value.slice(slashIdx);
    return (
      <div className="text-sm font-semibold text-slate-900">
        {left}
        <span className="font-medium text-slate-400">{right}</span>
      </div>
    );
  }
  return <div className="text-sm font-semibold text-slate-900">{value}</div>;
}

export default function ListingCard({
  item,
  onDetails = () => {},
  onToggleFavorite = () => {},
  className,
}) {
  const rooms = item.roomsLabel ?? item.stats?.[0];
  const area = item.areaLabel ?? item.stats?.[1];

  return (
    <article
      className={cn(
        "w-full max-w-[260px] overflow-hidden rounded-2xl bg-white",
        "ring-1 ring-black/10",
        "shadow-sm",
        className
      )}
    >
      {/* IMAGE */}
      <div className="relative aspect-[16/9] w-full overflow-hidden">
        <img
          src={item.image}
          alt={item.title}
          className="h-full w-full object-cover object-center"
          loading="lazy"
          decoding="async"
          draggable={false}
        />

        {/* Badges */}
        <div className="absolute left-3 top-3 flex flex-col gap-2">
          {item.verified && (
            <span className="w-fit rounded-full bg-white/95 px-3 py-1 text-[11px] font-semibold text-slate-900 shadow-sm">
              {SITE.listing.badges.verified}
            </span>
          )}
          {item.isNew && (
            <span className="w-fit rounded-full bg-white/95 px-3 py-1 text-[11px] font-semibold text-slate-900 shadow-sm">
              {SITE.listing.badges.new}
            </span>
          )}
        </div>

        {/* Heart */}
        <button
          type="button"
          aria-label="Save listing"
          onClick={onToggleFavorite}
          className="absolute right-3 top-3 grid h-10 w-10 place-items-center rounded-full bg-white/95 shadow-sm"
        >
          <IconHeart className="h-5 w-5" />
        </button>
      </div>

      {/* BODY */}
      <div className="px-4 pb-4 pt-4">
        <h3 className="text-[16px] font-semibold leading-snug text-slate-900">
          {item.title}
        </h3>

        <div className="mt-2.5 flex items-center gap-2.5">
          <IconPin className="h-5 w-5 shrink-0" />
          <p className="text-[13px] font-medium text-slate-400">{item.location}</p>
        </div>

        <div className="mt-3 flex items-center gap-6 text-slate-400">
          <div className="flex items-center gap-2">
            <IconBed className="h-5 w-5" />
            <span className="text-[12px] font-medium">{rooms}</span>
          </div>

          <div className="flex items-center gap-2">
            <IconArea className="h-5 w-5" />
            <span className="text-[12px] font-medium">{area}</span>
          </div>
        </div>

        <div className="mt-3.5 h-px w-full bg-slate-200" />

        <div className="mt-3.5 flex items-center justify-between">
          <Price value={item.price} />
          <button
            type="button"
            onClick={onDetails}
            className="text-[12px] font-medium text-[#D66557] hover:opacity-90"
          >
            {SITE.listing.details}
          </button>
        </div>
      </div>
    </article>
  );
}