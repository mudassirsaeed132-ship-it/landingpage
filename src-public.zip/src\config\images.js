// src/config/images.js
const BASE = import.meta.env.BASE_URL || "/";

export const IMG = {
  brand: {
    logoFull: `${BASE}images/brand/logo-full.png`,
    logo: `${BASE}images/brand/logo.png`,
    flagUK: `${BASE}images/brand/uk-flag.png`,
  },

  hero: {
    home: `${BASE}images/hero/hero.jpg`,
  },

  categories: {
    buy: `${BASE}images/categories/buy.png`,
    rent: `${BASE}images/categories/rent.png`,
    land: `${BASE}images/categories/land.png`,
    commercial: `${BASE}images/categories/commercial.png`,
    shortStay: `${BASE}images/categories/short-stay.png`,
  },

  listings: [
    `${BASE}images/listings/listing-1.png`,
    `${BASE}images/listings/listing-2.png`,
    `${BASE}images/listings/listing-3.png`,
    `${BASE}images/listings/listing-4.png`,
  ],

  ui: {
    googlePlay: `${BASE}images/ui/google-play.png`,
    appGallery: `${BASE}images/ui/app-gallery.png`,
    appMock: `${BASE}images/ui/app-mock.png`,
  },
};